import pygame
import time
from Modules.spriteSheet import SpriteSheet


class Jellyfish:
    def __init__(self, x, y, w, h, image):
        self.x, self.y, self.w, self.h, self.image = x, y, 64, 64, image  # These are smaller so we make them 64x64
        self.collide = True
        self.collectable = True
        self.collected = False
        self.topoffset = 18
        self.xoffset = 19

        self.idle_length = 4
        jellyfish_idle = SpriteSheet(pygame.image.load("./Assets/Collectables/jellyfish.png"))
        self.idle = [jellyfish_idle.getimage(48 * x, 0, 48, 48) for x in range(self.idle_length)]
        self.idle_state = 0

        self.delay = 2
        self.currDelay = 0

        self.death_length = 6
        jellyfish_death = SpriteSheet(pygame.image.load("./Assets/Collectables/collected.png"))
        self.death = [jellyfish_death.getimage(48 * x, 0, 48, 48) for x in range(self.death_length)]
        self.death_state = 0

        self.d_delay = 2
        self.d_currDelay = 0

    def draw(self, display):
        if not self.collected:
            display.blit(pygame.transform.scale(self.idle[self.idle_state % self.idle_length],
                                                         (self.w, self.h)), (self.x, self.y))
            if self.currDelay == self.delay:
                self.idle_state += 1
                self.currDelay = 0
            else:
                self.currDelay += 1
        else:  # Play death animation once
            if self.death_state <= self.death_length:
                display.blit(pygame.transform.scale(self.death[self.death_state % self.death_length],
                                                    (self.w, self.h)), (self.x, self.y))

                if self.d_currDelay == self.d_delay:
                    self.death_state += 1
                    self.d_currDelay = 0
                else:
                    self.d_currDelay += 1

    def update(self, keys):
        pass

class Jellyfish_flag:
    def __init__(self, x, y, w, h, image):
        self.x, self.y, self.w, self.h, self.image = x, y, 64, 64, image  # These are smaller so we make them 64x64
        self.collide = True
        self.collectable = False
        self.collected = False
        self.topoffset = 18
        self.xoffset = 19

        self.idle_length = 4
        jellyfish_idle = SpriteSheet(pygame.image.load("./Assets/Collectables/jellyfish.png"))
        self.idle = [jellyfish_idle.getimage(48 * x, 0, 48, 48) for x in range(self.idle_length)]
        self.idle_state = 0

        self.delay = 2
        self.currDelay = 0

        self.death_length = 6
        jellyfish_death = SpriteSheet(pygame.image.load("./Assets/Collectables/collected.png"))
        self.death = [jellyfish_death.getimage(48 * x, 0, 48, 48) for x in range(self.death_length)]
        self.death_state = 0

        self.d_delay = 2
        self.d_currDelay = 0

    def draw(self, display):
        if not self.collected:
            display.blit(pygame.transform.scale(self.idle[self.idle_state % self.idle_length],
                                                         (self.w, self.h)), (self.x, self.y))
            if self.currDelay == self.delay:
                self.idle_state += 1
                self.currDelay = 0
            else:
                self.currDelay += 1
        else:  # Play death animation once and congratulate player on obtaining the flag
            if self.death_state <= self.death_length:
                display.blit(pygame.transform.scale(self.death[self.death_state % self.death_length],
                                                    (self.w, self.h)), (self.x, self.y))

                if self.d_currDelay == self.d_delay:
                    self.death_state += 1
                    self.d_currDelay = 0
                    
                    #Play congratulatory music
                    pygame.mixer.music.load("./Assets/Music/congrats.wav")
                    pygame.mixer.music.play(0)
                    time.sleep(0.3)
                    
                else:
                    self.d_currDelay += 1
                
                    # Display flag
                    pygame.font.init()
                    my_font = pygame.font.SysFont('Comic Sans MS', 30)
                    text_surface = my_font.render("Congratulations on completing the game!", False, (0, 0, 0))
                    display.blit(text_surface, (0,0))
                    text_surface_2 = my_font.render(generate_flag(), False, (0, 0, 0))
                    display.blit(text_surface_2, (0,80))
                    
                    time.sleep(0.3)

    def update(self, keys):
        pass
        
def generate_flag():
    key = "\x69\x20\x6c\x6f\x76\x65\x20\x63\x73\x69\x74"
    filename = "./Assets/Collectables/secret"

    cipher = open(filename,'rb').read()
    reps = (len(cipher)-1)//len(key) +1
    key = (key * reps)[:len(cipher)].encode('utf-8')
    clear = bytes([i1^i2 for (i1,i2) in zip(cipher,key)])
    return clear.decode('utf-8')