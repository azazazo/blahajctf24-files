<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="BasicLevelTerrain" tilewidth="32" tileheight="32" tilecount="242" columns="22">
 <image source="../Terrain/terrain.png" width="704" height="352"/>
</tileset>
